valid_email = 'lulmajistu@vusra.com'
valid_password = '12Jw?!'

valid_name = 'rex'
valid_animal_type = 'bulldog'
valid_age = '2'
valid_filter = 'my_pets'

